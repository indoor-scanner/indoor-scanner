#include "newStep.h"


stepMotor::stepMotor(){
	int read_iteration = 0;
	int direction = 0;
	int speed = 0;
	int step_delay = 0;
	int number_of_steps = 200;
	int last_step_angle = 0;
	int last_step_time = 0;
	int step_number = 0;
	int degree = 0;
}
void stepMotor::increaseStep(int currentStep){

	int angleCounter = 0;
	int degreeInc = 0;

	// @TODO: insert pins and names
	// switch(thisStep){
	// 	case 0: // 1010
	// 		digitalWrite(controller[0], b.HIGH);
	// 		digitalWrite(controller[1], b.LOW);
	// 		digitalWrite(controller[2], b.HIGH);
	// 		digitalWrite(controller[3], b.LOW);
	// 	break;
	// 	case 1: // 0110
	// 		digitalWrite(controller[0], b.LOW);
	// 		digitalWrite(controller[1], b.HIGH);
	// 		digitalWrite(controller[2], b.HIGH);
	// 		digitalWrite(controller[3], b.LOW);
	// 	break;
	// 	case 2: // 0101
	// 		digitalWrite(controller[0], b.LOW);
	// 		digitalWrite(controller[1], b.HIGH);
	// 		digitalWrite(controller[2], b.LOW);
	// 		digitalWrite(controller[3], b.HIGH);
	// 	break;
	// 	case 3: // 1001
	// 		digitalWrite(controller[0], b.HIGH);
	// 		digitalWrite(controller[1], b.LOW);
	// 		digitalWrite(controller[2], b.LOW);
	// 		digitalWrite(controller[3], b.HIGH);
	// 	break;
	// }

	if(direction == 0)
		degreeInc = -0.597;
	else if(direction == 1)
		degreeInc = 0.597;

	degree += degreeInc;
	// TODO read distance???


}
void stepMotor::setSpeed(int desiredSpeed){
	step_delay = 60 * 1000 * 1000 / number_of_steps / desiredSpeed;
}
void stepMotor::step(int steps_to_move){

	// TODO: abs in arduino?
	// steps_left = abs(steps_to_move);
	int steps_left = 0;

	if(steps_to_move > 0)
		direction = 1;
	else
		direction = 0;
	while(steps_left > 0){

		// int current_step_time = micros();
		int current_step_time = 0;
		if(current_step_time - last_step_time >= step_delay){
			last_step_time = current_step_time;
			if(direction == 1){
				step_number++;
				if(step_number == number_of_steps)
					step_number = 0;
			
			}
			else{
				if(step_number == 0)
					step_number = number_of_steps;
				step_number--;
			}
			steps_left--;
			increaseStep(step_number % 4);
		}

	}

}
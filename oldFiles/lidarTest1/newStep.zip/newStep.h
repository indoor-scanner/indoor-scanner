class stepMotor{
	public:
		stepMotor();
		void increaseStep(int currentStep);
		void setSpeed(int desiredSpeed);
		void step(int steps_to_move);
	private:
		int read_iteration;
		int direction;
		int speed;
		int step_delay;
		int number_of_steps;
		int last_step_angle;
		int last_step_time;
		int step_number;
		int degree;
};
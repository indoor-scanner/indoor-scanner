#include "Camera.h"


Camera::Camera()
{
	_speed = 0.5f;
}


Camera::~Camera()
{
}

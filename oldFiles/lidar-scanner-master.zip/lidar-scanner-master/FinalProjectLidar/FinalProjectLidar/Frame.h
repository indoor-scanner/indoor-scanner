#pragma once
class Frame
{
public:
	Frame();
	virtual ~Frame();
};

